"""
main.py
=======
ORKESTRASI PIPELINE (sesuai diagram desain sistem):
Parsing -> Extract Parameter -> Rule-based Comparator
        -> Calculate Score -> Output Format Score

Setiap tahap adalah modul terpisah:
    parser.py      -> Parsing
    extractor.py   -> Extract Parameter
    comparator.py  -> Rule-based Comparator
    scorer.py      -> Calculate Score
    (main.py ini)  -> Output Format Score

CHANGELOG (revisi):
- compare_all sekarang mengembalikan (findings, checks); checks dipakai
  scorer untuk skor per bab.
- findings dikelompokkan per bab di output JSON supaya gampang ditelusuri
  "bab 1 salahnya apa saja", tanpa mengubah isi tiap finding.
- Tahap terakhir aggregation diganti dari "Sort by Severity" (sudah
  dihapus) menjadi "Group by Chapter -> Sort by Location".
- Render ke PDF (LibreOffice) sekarang dipindah ke SINI (main.py),
  bukan lagi di dalam check_page_layout(). Alasannya: nomor halaman
  fisik hasil render dibutuhkan DUA tempat -- check_page_layout()
  (cek ganjil/genap awal bab) DAN compare_page_numbering() di
  comparator.py (buat kasih lokasi "Halaman N" yang spesifik di
  finding penomoran halaman, bukan cuma "Section #N" yang abstrak).
  Kalau render tetap di dalam check_page_layout(), dokumen yang sama
  bakal di-convert ke PDF DUA KALI lewat LibreOffice -- mahal & lambat.
  Jadi sekarang render sekali di sini, hasilnya (page_texts) dipakai
  bareng oleh kedua fungsi tsb.

Cara pakai:
    python main.py path/ke/dokumen.docx
"""

import sys
import re
import json
from collections import defaultdict

from aggregator.pipelines.visual.parser import parse_docx
from aggregator.pipelines.visual.extractor import extract_all
from aggregator.pipelines.visual.comparator import compare_all
from aggregator.pipelines.visual.page_layout_checker import (
    render_to_pdf,
    extract_page_texts,
    extract_footer_numbers,
    check_page_layout,
    find_section_start_pages,
)
from aggregator.pipelines.visual.scorer import calculate_score
from aggregator.pipelines.visual.bibliography_checker import check_bibliography


def _chapter_sort_key(chapter: str):
    """
    Urutan tampil yang natural: Pra-Bab dulu, lalu BAB 1/2/3/... urut
    angka, baru grup "Umum (...)" dan DAFTAR PUSTAKA di akhir.
    """
    if chapter == "Pra-Bab":
        return (0, 0, chapter)
    m = re.match(r"^BAB\s+(\d+)", chapter)
    if m:
        return (1, int(m.group(1)), chapter)
    if chapter == "DAFTAR PUSTAKA":
        return (3, 0, chapter)
    return (2, 0, chapter)


def group_findings_by_chapter(findings: list[dict]) -> dict:
    grouped = defaultdict(list)
    for f in findings:
        grouped[f["chapter"]].append({k: v for k, v in f.items() if k != "chapter"})
    return {
        chapter: grouped[chapter] for chapter in sorted(grouped, key=_chapter_sort_key)
    }


def merge_checks(base: dict, extra: dict) -> dict:
    """Gabung dua dict checks ({chapter: {checked, failed}}) dengan menjumlahkan."""
    merged = defaultdict(lambda: {"checked": 0, "failed": 0})
    for source in (base, extra):
        for chapter, c in source.items():
            merged[chapter]["checked"] += c["checked"]
            merged[chapter]["failed"] += c["failed"]
    return dict(merged)


def run_pipeline(filepath: str) -> dict:
    # 1. Parsing
    doc = parse_docx(filepath)

    # 2. Extract Parameter
    params = extract_all(doc)

    # 2b. Render ke PDF SEKALI di sini. Hasilnya (page_texts) dipakai
    #     bareng oleh check_page_layout() (cek ganjil/genap bab) DAN
    #     find_section_start_pages() (buat lokasi halaman fisik di
    #     finding penomoran halaman) -- supaya dokumen yang sama tidak
    #     di-render dua kali lewat LibreOffice.
    pdf_path = render_to_pdf(filepath)
    page_texts = extract_page_texts(pdf_path)
    # Angka footer beneran (ground truth per koordinat fisik) -- dipakai
    # check_page_layout() sebagai prioritas utama buat cek ganjil/genap,
    # supaya kebal dari perbedaan jumlah halaman fisik hasil render di
    # environment yang beda (mis. font "Times New Roman" gak terpasang
    # di server -> LibreOffice substitusi font lain -> wrapping geser).
    footer_numbers = extract_footer_numbers(pdf_path)
    section_pages = find_section_start_pages(page_texts, params["paragraphs"])

    # 3. Rule-based Comparator
    findings, checks = compare_all(params, section_pages)

    # 3b. Render & Locate: cek halaman ganjil/genap awal Bab (page_texts
    #     sudah tersedia dari langkah 2b, tidak render ulang)
    layout_findings, layout_checks = check_page_layout(
        page_texts, params["sections"], section_pages, footer_numbers
    )
    findings = findings + layout_findings
    checks = merge_checks(checks, layout_checks)

    bib_findings, bib_checks = check_bibliography(params["paragraphs"])
    findings = findings + bib_findings
    checks = merge_checks(checks, bib_checks)

    # 4. Calculate Score (per bab)
    summary = calculate_score(checks)
    summary["per_chapter"] = {
        chapter: summary["per_chapter"][chapter]
        for chapter in sorted(summary["per_chapter"], key=_chapter_sort_key)
    }

    # 5. Output Format Score
    return {
        "findings_per_chapter": group_findings_by_chapter(findings),
        "summary": summary,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python main.py path/ke/dokumen.docx [output.json]")
        sys.exit(1)

    filepath = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else "CheckRun/output/hasil.json"

    result = run_pipeline(filepath)

    # Tulis hasil LENGKAP ke file (tidak dipotong seperti kalau print ke terminal)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    # Terminal nampilin ringkasan per bab
    summary = result["summary"]
    print("=" * 55)
    print(f"Skor keseluruhan : {summary['overall_score']}")
    print(f"Total temuan     : {summary['total_findings']}")
    print("-" * 55)
    for chapter, c in summary["per_chapter"].items():
        print(
            f"  {chapter:<28} {c['score']:>6.2f}  ({c['failed']}/{c['checked']} gagal)"
        )
    print("=" * 55)
